import type { NavigationState } from '@react-navigation/routers';
export default function checkDuplicateRouteNames(state: NavigationState): string[][];
//# sourceMappingURL=checkDuplicateRouteNames.d.ts.map