/**
 * Compare two arrays with primitive values as the content.
 * We need to make sure that both values and order match.
 */
export default function isArrayEqual(a: any[], b: any[]): boolean;
//# sourceMappingURL=isArrayEqual.d.ts.map