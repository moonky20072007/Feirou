import type { NavigationContainerRefWithCurrent } from './types';
export default function useNavigationContainerRef<ParamList extends {} = ReactNavigation.RootParamList>(): NavigationContainerRefWithCurrent<ParamList>;
//# sourceMappingURL=useNavigationContainerRef.d.ts.map