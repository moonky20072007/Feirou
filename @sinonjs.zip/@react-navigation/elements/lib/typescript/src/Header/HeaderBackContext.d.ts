/// <reference types="react" />
declare const HeaderBackContext: import("react").Context<{
    title: string;
} | undefined>;
export default HeaderBackContext;
//# sourceMappingURL=HeaderBackContext.d.ts.map