/// <reference types="react" />
declare const HeaderShownContext: import("react").Context<boolean>;
export default HeaderShownContext;
//# sourceMappingURL=HeaderShownContext.d.ts.map