export default function useHeaderHeight(): number;
//# sourceMappingURL=useHeaderHeight.d.ts.map