export { default } from './MaskedViewNative';
//# sourceMappingURL=MaskedView.android.d.ts.map