/**
 * Navigators
 */
export { default as createNativeStackNavigator } from './navigators/createNativeStackNavigator';
/**
 * Views
 */
export { default as NativeStackView } from './views/NativeStackView';
/**
 * Types
 */
export type { NativeStackHeaderProps, NativeStackNavigationEventMap, NativeStackNavigationOptions, NativeStackNavigationProp, NativeStackScreenProps, } from './types';
//# sourceMappingURL=index.d.ts.map