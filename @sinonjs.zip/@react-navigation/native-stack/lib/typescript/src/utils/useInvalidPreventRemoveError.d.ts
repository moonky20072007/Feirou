import type { NativeStackDescriptorMap } from '../types';
export default function useInvalidPreventRemoveError(descriptors: NativeStackDescriptorMap): void;
//# sourceMappingURL=useInvalidPreventRemoveError.d.ts.map