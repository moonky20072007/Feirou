export declare function processFonts(_: (string | undefined)[]): (string | undefined)[];
//# sourceMappingURL=FontProcessor.d.ts.map