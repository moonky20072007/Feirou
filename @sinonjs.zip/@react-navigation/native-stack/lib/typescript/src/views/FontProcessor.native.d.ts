export declare function processFonts(fontFamilies: (string | undefined)[]): (string | undefined)[];
//# sourceMappingURL=FontProcessor.native.d.ts.map