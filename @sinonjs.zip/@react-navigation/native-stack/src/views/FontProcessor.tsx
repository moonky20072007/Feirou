export function processFonts(
  _: (string | undefined)[]
): (string | undefined)[] {
  throw new Error('Not supported on Web');
}
