export default function extractPathFromURL(prefixes: string[], url: string): string | undefined;
//# sourceMappingURL=extractPathFromURL.d.ts.map