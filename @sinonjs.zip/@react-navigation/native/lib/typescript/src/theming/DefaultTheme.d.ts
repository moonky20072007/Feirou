import type { Theme } from '../types';
declare const DefaultTheme: Theme;
export default DefaultTheme;
//# sourceMappingURL=DefaultTheme.d.ts.map