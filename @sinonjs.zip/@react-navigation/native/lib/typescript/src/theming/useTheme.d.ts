export default function useTheme(): import("..").Theme;
//# sourceMappingURL=useTheme.d.ts.map