/// <reference types="react" />
import type { NavigationContainerRef, ParamListBase } from '@react-navigation/core';
export default function useBackButton(_: React.RefObject<NavigationContainerRef<ParamListBase>>): void;
//# sourceMappingURL=useBackButton.d.ts.map