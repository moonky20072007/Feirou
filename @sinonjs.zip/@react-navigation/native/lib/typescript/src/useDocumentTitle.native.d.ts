export default function useDocumentTitle(): void;
//# sourceMappingURL=useDocumentTitle.native.d.ts.map