declare function _exports(value: any): string;
export = _exports;
