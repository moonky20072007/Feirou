'use strict';
require('../register')('rsvp', {Promise: require('rsvp').Promise})
