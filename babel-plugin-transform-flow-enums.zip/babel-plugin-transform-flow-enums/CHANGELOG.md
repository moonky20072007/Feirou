# 0.0.2
- Update README documentation

# 0.0.1
- Initial version
