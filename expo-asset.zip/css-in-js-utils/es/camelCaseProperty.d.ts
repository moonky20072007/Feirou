export default function camelCaseProperty(property: string): string;
