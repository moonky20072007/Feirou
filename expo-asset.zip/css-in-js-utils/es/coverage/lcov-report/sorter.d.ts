declare function addSorting(): void;
