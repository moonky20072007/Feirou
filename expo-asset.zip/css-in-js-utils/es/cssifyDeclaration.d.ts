export default function cssifyDeclaration(property: string, value: string | number): string;
