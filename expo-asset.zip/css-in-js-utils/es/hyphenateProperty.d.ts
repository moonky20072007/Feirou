export default function hyphenateProperty(property: string | number): string;
