export default function isPrefixedProperty(property: string): boolean;
