export default function isPrefixedValue(value: string): boolean;
