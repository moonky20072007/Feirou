export default function isUnitlessProperty(property: string): boolean;
