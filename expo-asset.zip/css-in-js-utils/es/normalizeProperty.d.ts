export default function normalizeProperty(property: string): string;
