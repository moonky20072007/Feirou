export default function resolveArrayValue(property: string, value: string[]): string;
