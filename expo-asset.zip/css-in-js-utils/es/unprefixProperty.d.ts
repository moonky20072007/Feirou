export default function unprefixProperty(property: string): string;
