export default function unprefixValue(value: string | string[]): string | string[];
