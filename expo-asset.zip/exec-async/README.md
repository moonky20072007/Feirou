# exec-async
Returns a promise with the results of a shell command
