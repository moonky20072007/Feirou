module.exports = require('jest-expo/rsc/jest-preset');
