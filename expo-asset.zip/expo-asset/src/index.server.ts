export * from './Asset.server';

export function useAssets() {
  return [[], undefined];
}
