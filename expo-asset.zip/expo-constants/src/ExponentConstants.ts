import { requireOptionalNativeModule } from 'expo-modules-core';

export default requireOptionalNativeModule('ExponentConstants');
