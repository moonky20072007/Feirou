import registerRootComponent from 'expo/src/launch/registerRootComponent';

import App from '../../App';

registerRootComponent(App);
