module.exports = require('@expo/config-plugins');
