module.exports = require('@expo/config');
