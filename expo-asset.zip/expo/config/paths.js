module.exports = require('@expo/config/paths');
