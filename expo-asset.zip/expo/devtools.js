module.exports = require('@expo/devtools');
