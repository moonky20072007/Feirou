// Contents of this file are generated in the transformer.
