export * from '../src/dom/global-events';
