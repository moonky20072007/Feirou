module.exports = require('@expo/fingerprint');
