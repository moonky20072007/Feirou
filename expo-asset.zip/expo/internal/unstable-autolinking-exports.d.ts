// WARN: Internal re-export, you should avoid relying on this, if possible. Expect breaking changes between SDK releases
export * from 'expo-modules-autolinking/exports';
