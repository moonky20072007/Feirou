// WARN: Internal re-export, you should avoid relying on this, if possible. Expect breaking changes between SDK releases
module.exports = require('expo-modules-autolinking/exports');
