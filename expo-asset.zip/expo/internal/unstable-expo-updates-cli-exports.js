// WARN: Internal re-export, don't rely on this to be a public API or use it outside of `expo/expo`'s monorepo
module.exports = require('@expo/cli/internal/unstable-expo-updates-exports');
