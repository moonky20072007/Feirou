// Copyright 2016-present 650 Industries. All rights reserved.

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/**
 This class loads some preprocessors and pass into `EXAppDefines` of ExpoModulesCore.
 */
@interface EXAppDefinesLoader : NSObject

@end

NS_ASSUME_NONNULL_END
