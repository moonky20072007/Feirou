// @ts-expect-error
import getDevServer from 'react-native/Libraries/Core/Devtools/getDevServer';

export default getDevServer;
