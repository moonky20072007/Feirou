const HMRClient = require('react-native/Libraries/Utilities/HMRClient').default;

export default HMRClient;
