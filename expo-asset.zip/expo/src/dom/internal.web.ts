export { registerDOMComponent } from './dom-entry';
