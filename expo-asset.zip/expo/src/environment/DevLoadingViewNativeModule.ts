export default Object.freeze({
  name: 'DevLoadingView',
  startObserving() {},
  stopObserving() {},
  addListener() {},
  removeListeners() {},
});
