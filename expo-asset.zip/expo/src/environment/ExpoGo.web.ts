export function isRunningInExpoGo() {
  return false;
}

export function getExpoGoProjectConfig() {
  return null;
}
