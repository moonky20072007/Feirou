export function getInitialSafeArea(): { top: number; bottom: number; left: number; right: number } {
  return {
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
  };
}
