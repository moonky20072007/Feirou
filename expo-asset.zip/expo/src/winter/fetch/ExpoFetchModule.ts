import { requireNativeModule } from 'expo-modules-core';

export const ExpoFetchModule = requireNativeModule('ExpoFetchModule');
