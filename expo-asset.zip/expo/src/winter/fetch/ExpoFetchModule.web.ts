class StubNativeRequest {}
class StubNativeResponse {}

export const ExpoFetchModule = {
  NativeRequest: StubNativeRequest,
  NativeResponse: StubNativeResponse,
};
