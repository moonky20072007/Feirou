export const fetch = globalThis.fetch;
