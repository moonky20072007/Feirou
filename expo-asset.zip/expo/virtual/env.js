// virtual module for client environment variables in development.
export const env = process.env;
