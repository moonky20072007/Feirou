import { Delay } from "../delay.base";

export class AlwaysDelay extends Delay {}