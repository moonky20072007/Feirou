export function noJitter(delay: number) {
    return delay;
}