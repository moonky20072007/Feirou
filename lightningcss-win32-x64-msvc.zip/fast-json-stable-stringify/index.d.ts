declare module 'fast-json-stable-stringify' {
  function stringify(obj: any): string;
  export = stringify;
}
