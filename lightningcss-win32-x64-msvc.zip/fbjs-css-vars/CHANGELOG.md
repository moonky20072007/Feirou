## [1.0.2] - 2018-12-17

### Changed
- Relicensed to MIT.


## [1.0.1] - 2017-07-18

### Fixed
- Added `repository` field in `package.json` to fix issue with some tools.


## [1.0.0] - 2016-07-14

### Added
- Initial release with variables used by Fixed Data Table and Draft.
