export function isJscSafeUrl(url: string): boolean;
export function toNormalUrl(urlToNormalize: string): string;
export function toJscSafeUrl(urlToConvert: string): string;
