import { Long } from "./types.js";
export = Long;
export as namespace Long;
