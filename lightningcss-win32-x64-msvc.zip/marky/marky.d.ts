/* eslint-disable */

export declare const mark: (name: string) => void

export declare const stop: (name: string) => PerformanceEntry

export declare const getEntries: () => PerformanceEntry[]

export declare const clear: () => void