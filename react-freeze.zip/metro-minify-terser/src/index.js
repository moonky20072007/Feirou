"use strict";

const minifier = require("./minifier");
module.exports = minifier;
