# metro-resolver

🚇 [Metro](https://metrobundler.dev/) resolution logic
