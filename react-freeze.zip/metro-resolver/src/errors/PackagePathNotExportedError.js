"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true,
});
exports.default = void 0;
class PackagePathNotExportedError extends Error {}
exports.default = PackagePathNotExportedError;
