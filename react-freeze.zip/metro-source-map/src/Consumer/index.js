"use strict";

const DelegatingConsumer = require("./DelegatingConsumer");
module.exports = DelegatingConsumer;
