declare function setMaxParserCache(max: number): void;
declare function clearParserCache(): void;

export { setMaxParserCache, clearParserCache };
