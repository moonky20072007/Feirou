## 2.0.0

* Added support for node v7
* Dropped support for node v0.8 and v0.6
